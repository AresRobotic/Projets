/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <project.h>
#define period1 20
#define period2 25
#define period3 30
#define periodLCD 2000000
#define nbmessages 10


int cpt1,cpt2,cpt3,cpt4,i,period,cmp1,cmp2,cmp3,updown1=1,updown2=1,updown3=1;

char messagesl1[nbmessages][16] = { 
  "      ENSEA     ",
  "    You are     ",
  "Hamming",
  "Minsky",
  "Wilkinson",
  "McCarthy",
  "Dijkstra",
  "Bachman",
  "Knuth",
  "Newell & Simon"
};
char messagesl2[nbmessages][16] = { 
  "   PROMO 2017   ",
  "    AWESOME     ",
  "Hamming",
  "Minsky",
  "Wilkinson",
  "McCarthy",
  "Dijkstra",
  "Bachman",
  "Knuth",
  "Newell & Simon"
};

//
//CY_ISR(ISR_1_Interrupt){
//    
//    ISR_1_ClearPending();
//    cmp = PWM_1_ReadCompare() ;
//    if( updown == 1){
//        //PWM_1_SetPWMInvert(PWM_1_INVERT_LINE);
//        PWM_1_WriteCompare(cmp+1);
//        if(cmp == (period-1)){
//            updown =0;
//        }
//    }
//    else if( updown == 0){
//        PWM_1_WriteCompare(cmp-1);   
//        if(cmp == 1){
//            updown =1 ;
//        }
//    }
//    
//}

int main()
{
    //char command, b;
    
    /* Place your initialization/startup code here (e.g. MyInst_Start()) */

    /* CyGlobalIntEnable; */ /* Uncomment this line to enable global interrupts. */
    
    //uint32 rxData;  
    //ISR_1_Start();
    
    
    //initialisation LCD
    LCD_Char_1_Start();

    
    /* Initialisation affichage */
    LCD_Char_1_Position(0u, 0u);
    LCD_Char_1_PrintString("  Made by ARES  ");
    LCD_Char_1_Position(1u, 0u);
    LCD_Char_1_PrintString(" Just for U ");

   
    //initialisation UART
    //UART_1_Start();
 

    //initialisation des PWMs 
    PWM_1_Start();
    PWM_3_Start();
    PWM_2_Start();

    
    period = PWM_1_ReadPeriod();
    cpt1 =0 ;
    cpt2=0;
    cpt3=0;
    
    cpt4=0;
    i = 0;

    for(;;)
    {
        cpt1++;
        cpt2++;
        cpt3++;
        cpt4++;
        
        if(cpt1== period1){
            cmp1 = PWM_1_ReadCompare() ;
            if( updown1 == 1){
                PWM_1_WriteCompare(cmp1+1);
                if(cmp1 == (period-20)){
                    updown1 =0;
                }
            }
            else if( updown1 == 0){
                PWM_1_WriteCompare(cmp1-1);   
                if(cmp1 == 20){
                    updown1 =1 ;
                }
            }
            cpt1=0;
        }
        if(cpt2==period2){
            cmp2 = PWM_2_ReadCompare() ;
            if( updown2 == 1){
                PWM_2_WriteCompare(cmp2+1);
                if(cmp2 == (period-20)){
                    updown2 =0;
                }
            }
            else if( updown2 == 0){
                PWM_2_WriteCompare(cmp2-1);   
                if(cmp2 == 20){
                    updown2 =1 ;
                }
            }
            cpt2=0;
        }
        if(cpt3==period3){
            cmp3 = PWM_3_ReadCompare() ;
            if( updown3 == 1){
                PWM_3_WriteCompare(cmp3+1);
                if(cmp3 == (period-20)){
                    updown3 =0;
                }
            }
            else if( updown3 == 0){
                PWM_3_WriteCompare(cmp3-1);   
                if(cmp3 == 20){
                    updown3 =1 ;
                }
            }
            cpt3=0;
        }
        
        if(cpt4==periodLCD){
            LCD_Char_1_ClearDisplay();
            //LCD_Char_1_Position(0u, 0u);
            LCD_Char_1_PrintString(messagesl1[i]);
            LCD_Char_1_Position(1u, 0u);
            LCD_Char_1_PrintString(messagesl2[i]);
            cpt4 = 0;
            i++;
            if(i==nbmessages){
                i=0;
            }
        }
        
        
        
        
        
        
        
        
        
        
        //PWM_2_WriteCompare(PWM_2_ReadCompare()+2);
        //PWM_3_WriteCompare(PWM_3_ReadCompare()+3);
        
        
//        
//        rxData = UART_1_UartGetChar(); // store received characters in temporary variable
//
//        if(rxData == 'o') { // make sure data is non-zero
//            UART_1_UartPutChar(rxData); // echo characters in terminal window
//            LED_Write(1);
//            // Handle received characters
//            LCD_Char_1_ClearDisplay();
//            LCD_Char_1_PrintString("coucou o");
//        }
//        else if(rxData == 'n') { // make sure data is non-zero
//            UART_1_UartPutChar(rxData); // echo characters in terminal window
//            LED_Write(0);
//            // Handle received characters
//            LCD_Char_1_ClearDisplay();
//            LCD_Char_1_PrintString("coucou n");
//        }

        /* Place your application code here. */
    }
}

/* [] END OF FILE */
